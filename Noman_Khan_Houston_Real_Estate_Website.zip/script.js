
function toggleMenu(){document.querySelector('.navlinks').classList.toggle('open')}
function sendLead(e){
  e.preventDefault();
  const f=e.target;
  const data=new FormData(f);
  const lines=[];
  for(const [k,v] of data.entries()){if(v) lines.push(`${k}: ${v}`)}
  const msg="New Houston Real Estate Lead%0A%0A"+encodeURIComponent(lines.join("\n"));
  window.open("https://wa.me/923152948710?text="+msg,"_blank");
}
