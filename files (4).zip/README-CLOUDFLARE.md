# Bayou Oak Realty — website chalane ka mukammal tareeqa

Ye website poori static hai (sirf HTML, CSS, JS). Koi server, koi database, koi monthly cost nahi.
Cloudflare Pages ka free plan is ke liye kaafi hai.

---

## 1. Files ka structure

```
bayou-oak-realty/
├── index.html          (home page)
├── properties.html     (listings, filter buttons ke sath)
├── services.html       (services + overseas buyer process)
├── about.html          (company intro)
├── contact.html        (form -> seedha WhatsApp par)
├── style.css           (poori site ka design)
├── script.js           (menu, filter, form -> WhatsApp)
├── robots.txt
├── sitemap.xml
└── images/             (property photos yahan aayengi)
```

---

## 2. Cloudflare Pages par upload (5 minute)

1. **ZIP kholein**: `bayou-oak-realty.zip` ko apne computer par extract karein. Aap ko upar wala folder milega.
2. `dash.cloudflare.com` par jayein. Account na ho to free sign up karein (email + password).
3. Left menu se **Workers & Pages** → **Create** → tab **Pages** → **Upload assets**.
4. Project ka naam likhein: `bayou-oak-realty` → **Create project**.
5. Ab **poora folder drag & drop karein** (folder ke andar ki saari files, folder khud bhi chal jata hai) → **Deploy site**.
6. 20–30 second mein site live. Link kuch aisa hoga:
   `https://bayou-oak-realty.pages.dev`

Bas. Site duniya mein kahin se bhi khul jayegi.

---

## 3. Apna domain lagana (optional, lekin recommended)

1. Domain kharidein (Cloudflare Registrar, Namecheap, GoDaddy — sab theek hain).
   Pehle check karein ke `bayouoakrealty.com` available hai ya nahi.
2. Cloudflare dashboard → **Add a site** → apna domain likhein → free plan choose karein.
3. Cloudflare aap ko **2 nameservers** dega. Wo apne domain registrar ke panel mein ja kar
   purane nameservers ki jagah paste kar dein. (2–24 ghante mein active hota hai.)
4. Phir: **Workers & Pages** → apna project → **Custom domains** → **Set up a domain**
   → `bayouoakrealty.com` likh kar add karein. SSL/https Cloudflare khud laga dega.

---

## 4. Site update kaise karein

Koi bhi file notepad ya VS Code mein edit karein, save karein, phir:
Cloudflare → project → **Create deployment** → folder dobara upload → done.

**Aam edits:**

| Kya badalna hai | Kahan |
|---|---|
| WhatsApp number | `script.js` ki pehli line `WA_NUMBER` + har file mein `wa.me/923152948710` (find & replace) |
| Email address | har HTML file mein `hello@bayouoakrealty.com` |
| Naya listing add karna | `properties.html` mein kisi bhi `<article class="card">` block ko copy kar ke paste karein aur price/address/specs badal dein |
| Colors | `style.css` ki `:root` wali lines (`--pine`, `--sun`, `--paper`) |
| Property photos | `images/` folder mein `listing-1.jpg` se `listing-9.jpg` rakh dein |

---

## 5. Contact form kaise kaam karta hai

Static site par form email nahi bhej sakta, isliye form ka data
**WhatsApp message mein convert ho kar aap ke number par khul jata hai**.
Client "Send on WhatsApp" dabaye ga, uske phone par WhatsApp khulega, message pehle se likha hua hoga.
Aap ko ek lead ready milegi — na koi server chahiye, na koi fees.

Agar baad mein email par bhi lead chahiye ho to `formspree.io` (free tier) 5 minute mein lag jata hai.

---

## 6. Business shuru karne se pehle — zaroori baat

Texas mein property buy/sell karwa kar commission lena **licensed activity** hai.
Bina licence ke ye kaam karna TREC (Texas Real Estate Commission) ke qanoon ki khilaf warzi hai.
Practical raste:

- **Sponsoring broker ke sath partnership** — sab se aam tareeqa. Aap leads laate hain,
  licensed broker deal close karta hai, commission split hoti hai. Ye Pakistan se bhi possible hai
  (referral agreement ke zariye).
- **Khud licence lena** — 180 hours ki coursework, exam, phir sponsoring broker. Texas mein
  residency zaroori nahi, lekin process mein kuch mahine lagte hain.
- **Sirf investor/consulting model** — aap apni ya clients ki property khud khareedte/bechte hain
  (principal ke tor par), commission agent ban kar nahi lete.

Website ke footer mein IABS aur TREC Consumer Protection Notice ki jagah chhod di gayi hai —
jab licence/brokerage final ho jaye to wahan links laga dein.
